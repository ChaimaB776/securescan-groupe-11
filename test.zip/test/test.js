// index.js
const express = require('express');
const app = express();

// Exemple de vulnérabilité : utilisation de eval
const userInput = "1; DROP TABLE users";  // Exemple d'injection de code
eval(userInput); // EVITER d'utiliser eval avec des entrées utilisateurs !

// Exemple de vulnérabilité : Injection d'objet
let obj = {};
let property = "name";
obj[property] = "John";  // Risque d'injection d'objet

app.get('/', (req, res) => {
  res.send('Hello World!');
});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});