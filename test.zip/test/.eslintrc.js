import security from 'eslint-plugin-security';

export default [
  {
    plugins: ['security'],
    rules: {
      'security/detect-object-injection': 'warn',
      'security/detect-eval-with-expression': 'error'
    }
  }
];